This folder has all the files necessary to make Islandora work with CWRC .18

Two CWRC files have been modified - editor.js, and filemanager.js
In both case additional paramters have been passed in the config objects to
make the application aware of the PID of the object being edited.

index.php in the resources folder contains the page markup.


